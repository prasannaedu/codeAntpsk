import { LoginScreen } from "@/components/LoginScreen"

const Login = () => {
  return <LoginScreen />
}

export default Login